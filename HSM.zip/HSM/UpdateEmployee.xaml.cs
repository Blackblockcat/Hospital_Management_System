﻿using MaterialDesignColors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HSM
{
    /// <summary>
    /// Interaction logic for UpdateEmployee.xaml
    /// </summary>
    public partial class UpdateEmployee : Window
    {
        HSMEntities db = new HSMEntities(); 
        public UpdateEmployee()
        {
            InitializeComponent();
        }
        List<EMPLOYEE> ls = new List<EMPLOYEE>();
        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            ShowStff s=new ShowStff(); 
            this.Hide();
            s.Show();
        }

        private void save_Click(object sender, RoutedEventArgs e)
        {
            EMPLOYEE NEWIMP = db.EMPLOYEEs.Where(s => s.ID_Employee.ToString() == ID.Text.ToString()).SingleOrDefault();
            NEWIMP.Age = int.Parse(empAGE.textbox.Text);
            NEWIMP.Salary = Convert.ToDouble(empSalary.textbox.Text);
            NEWIMP.Phone = empPhone.textbox.Text;
            NEWIMP.Address = empAddress.textbox.Text;
            NEWIMP.Town = empCity.textbox.Text;

            db.SaveChanges();
        }

        private void search_Click(object sender, RoutedEventArgs e)
        {
            var item = from s in db.EMPLOYEEs.ToList()
                       where s.ID_Employee.ToString() == ID.Text.ToString()
                       select s;
            ls = item.ToList();

            foreach (var s in ls)
            {
                empAGE.textbox.Text = s.Age.ToString();
                empSalary.textbox.Text = s.Salary.ToString();
                empPhone.textbox.Text = s.Phone.ToString();
                empAddress.textbox.Text = s.Address.ToString();
                empCity.textbox.Text = s.Town.ToString();
            }


        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                this.DragMove();
            }
        }
    }
}
