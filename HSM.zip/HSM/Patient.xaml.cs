﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HSM
{
    /// <summary>
    /// Interaction logic for Patient.xaml
    /// </summary>
    public partial class Patient : Window
    {
        public Patient()
        {
            InitializeComponent();
        }
        HSMEntities db=new HSMEntities();   
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            HomePage homePage = new HomePage();
            this.Hide();
            homePage.Show();
        }

        private void search_Click(object sender, RoutedEventArgs e)
        {

            ID_TextChanged();
            
        }

        private void Name_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void id(object sender, TextChangedEventArgs e)
        {

        }

        private void membersDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
        private bool IsMaximize = false;
        private void Border_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2)
            {
                if (IsMaximize)
                {
                    this.WindowState = WindowState.Normal;
                    this.Width = 1300;
                    this.Height = 700;

                    IsMaximize = false;
                }
                else
                {
                    this.WindowState = WindowState.Maximized;

                    IsMaximize = true;
                }
            }
        }

        private void Border_MouseLeftButtonDown_1(object sender, MouseButtonEventArgs e)
        {

        }

        private void Name_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void Border_MouseLeftButtonDown_2(object sender, MouseButtonEventArgs e)
        {

        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                this.DragMove();
            }
        }

        


        

       
        private void ID_TextChanged()
        {
            var patients = db.PATIENTs.ToList();
            var appointments = db.APPOINTMENTs.ToList();
            var idPatient = ID.textbox.Text;

            var patches = from p in patients
                          where p.ID_Patient.ToString() == idPatient.ToString()
                          select p;

            membersDataGrid.ItemsSource = patches;
            //var items = from patientExam in model1.MEDICAL_EXAMINATIONS.ToList()
            //            join examType in model1.MEDICAL_EXAMINATIONS_TYPES.ToList()
            //                on patientExam.ME_ID equals examType.MeType_ID into examTypeGroups
            //            from examType in examTypeGroups.DefaultIfEmpty()
            //            join appointment in appointments
            //                on patientExam.ID_Patient.ToString() equals appointment.ID_Patient.ToString() into appGroups
            //            from appointment in appGroups.DefaultIfEmpty()
            //            join department in model1.DEPARTMENTs.ToList()
            //                on appointment?.ID_Dep equals department.ID_Dep into depGroups
            //            from department in depGroups.DefaultIfEmpty()
            //            where patientExam.ID_Patient.ToString() == idPatient
            //            select new
            //            {
            //                ID_Patient = patches.FirstOrDefault().ID_Patient,
            //                name_patient = patches.FirstOrDefault().name_patient,
            //                Age = patches.FirstOrDefault().Age,
            //                Gender = patches.FirstOrDefault().Gender,
            //                Town = patches.FirstOrDefault().Town,
            //                AddressS = patches.FirstOrDefault().AddressS,
            //                PHONE = patches.FirstOrDefault().PHONE,
            //                DepartmentName = department?.NAME_DEP,
            //                MedicalExaminationInfo = examType?.Type
            //            };
            var idDep = (from app in db.APPOINTMENTs.ToList()
                         where app.ID_Patient.ToString() == idPatient.ToString()
                         select app.ID_Dep).ToList();

            var nameDep = (from dep in db.DEPARTMENTs.ToList()
                           where idDep.Contains(dep.ID_Dep)
                           select dep).ToList();

            Department.ItemsSource = nameDep.Select(depName => new { DepartmentName = depName.NAME_DEP  });

            var idMed = (from app in db.MEDICAL_EXAMINATIONS.ToList()
                         where app.ID_Patient.ToString() == idPatient.ToString()
                         select app.MeType).ToList();

            var nameMed = (from medType in db.MEDICAL_EXAMINATIONS_TYPE.ToList()
                           where idMed.Contains(medType.ID)
                           select medType).ToList();

            Medical.ItemsSource = nameMed.Select(medName => new { MedicalTypeName = medName.ME_TYPE  });



            //    int id = int.Parse(ID.Text);


            //    //ASSIGN PATEINT_NAME
            //    PATIENT P = model1.PATIENTs.FirstOrDefault(n => n.ID_Patient == id);

            //    Name.Text = P.name_patient;

            //    //assaign Medical_examination
            //    //get_ID_TYPE
            //    var get_ID = from h in model1.MEDICAL_EXAMINATIONS
            //                 where h.ID_Patient == id
            //                 select h.MeType;
            //    var get_ID_TYPE = get_ID.FirstOrDefault();

            //    string get_NAME_ME = "NULL";

            //    //int get_me_id = 0;
            //    if (get_ID != null)
            //    {
            //        //  get_me_id
            //        var NAME_ME = from g in model1.MEDICAL_EXAMINATIONS_TYPES
            //                      where g.MeType_ID == get_ID_TYPE
            //                      select g.Type;
            //        get_NAME_ME = NAME_ME.FirstOrDefault();


            //    }

            //    //List<> ls = new List<>;

            //    // asseign appointments
            //    //get_appoint_id
            //    var appoint_id = from o in model1.APPOINTMENTs
            //                     where o.ID_Patient == id
            //                     select o.Appointment_id;
            //    var get_appoint_id = appoint_id.FirstOrDefault();


            //    string get_NAME_DEP = "NULL";


            //    if (appoint_id != null)
            //    { //get_id_DEP 
            //        var get_id = from d in model1.APPOINTMENTs
            //                     where d.ID_Patient == id
            //                     select d.ID_Dep;
            //        var get_id_DEP = get_id.FirstOrDefault();


            //        //get_NAME_DEP
            //        var NAME_DEP = from B in model1.DEPARTMENTs
            //                       where B.ID_Dep == get_id_DEP
            //                       select B.NAME_DEP;

            //        get_NAME_DEP = NAME_DEP.FirstOrDefault();

            //    }
            //         //ASSAIGN DATAGRID
            //         foreach(var x in )
            //    {

            //    }
            //    var query = new[] { new { ID = P.ID_Patient,Name = P.name_patient,Age = P.Age ,Address=P.AddressS,
            //        Gender=P.Gender,Town=P.Town,Phone = P.PHONE, DepartmentName = get_NAME_DEP, MedicalExaminationInfo = get_NAME_ME} };
            //    membersDataGrid.ItemsSource = query.ToList();





        }

    }
}

